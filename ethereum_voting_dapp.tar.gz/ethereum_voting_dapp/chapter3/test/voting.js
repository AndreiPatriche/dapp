const Voting = artifacts.require('Voting');

contract('Voting', accounts => {
 it("should be able to buy tokens", async() => {
  const instance = await Voting.deployed();
  await instance.buy({value: web3.utils.toWei('1', 'ether')});
  var tokensSold = await instance.tokensSold.call();

  var voterDetails = await instance.voterDetails.call(accounts[0]);
  var userTokens = voterDetails[0].toNumber();

  assert.equal(tokensSold, 100, "100 tokens were not sold");
  assert.equal(userTokens, 100, "100 tokens were not assigned to user");

 });

 it("should be able to vote for candidate", async() => {
  const instance = await Voting.deployed();
  await instance.buy({value: web3.utils.toWei('1', 'ether')});
   
  await instance.voteForCandidate(web3.utils.asciiToHex('Nick'), 25)

  var tokenDetails = await instance.voterDetails.call(accounts[0]);
   
  var tokensUsedPerCandidate = tokenDetails[1];

  assert.equal(tokensUsedPerCandidate[1], 25, "25 tokens were not voted for Nick");
 });

});
